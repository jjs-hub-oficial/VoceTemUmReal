# Você tem 1 real

Aplicativo Android independente com animação de uma moeda dourada e a mensagem:
"Você realmente tem um real?"

## Requisitos
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3
- Gradle 8.9

## Compilar
Na raiz do projeto:
```bash
gradle assembleDebug
```
APK esperado: `app/build/outputs/apk/debug/app-debug.apk`

Abra o aplicativo. A moeda gira; depois aparece a mensagem. Toque na tela para repetir.

Status: código-fonte gerado; não compilado nem testado neste ambiente.
