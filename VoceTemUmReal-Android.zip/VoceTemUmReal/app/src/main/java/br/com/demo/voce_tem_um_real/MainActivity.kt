package br.com.demo.voce_tem_um_real

import android.app.Activity
import android.animation.ValueAnimator
import android.graphics.*
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.cos

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 14, 24)
        window.navigationBarColor = Color.rgb(12, 14, 24)
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(12, 14, 24))
            addView(CoinIntroView())
        })
    }

    private inner class CoinIntroView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif-bold", Typeface.BOLD)
        }
        private var progress = 0f
        private var revealed = false

        init {
            isClickable = true
            startAnimation()
            setOnClickListener { startAnimation() }
        }

        private fun startAnimation() {
            revealed = false
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 3000
                interpolator = AccelerateDecelerateInterpolator()
                addUpdateListener {
                    progress = it.animatedValue as Float
                    if (progress >= 0.82f) revealed = true
                    invalidate()
                }
                start()
            }
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            val cx = w / 2f
            val cy = h * 0.40f
            text.color = Color.WHITE
            text.textSize = 25f
            canvas.drawText("UMA SURPRESA...", cx, h * 0.16f, text)

            val scale = abs(cos(progress * Math.PI * 8)).toFloat().coerceAtLeast(0.08f)
            val radius = (w * 0.19f).coerceAtMost(150f)
            canvas.save()
            canvas.translate(cx, cy)
            canvas.scale(scale, 1f)

            paint.style = Paint.Style.FILL
            paint.shader = RadialGradient(-radius * .3f, -radius * .35f, radius * 1.5f,
                intArrayOf(Color.rgb(255,238,150), Color.rgb(214,151,35), Color.rgb(130,79,12)),
                null, Shader.TileMode.CLAMP)
            canvas.drawCircle(0f, 0f, radius, paint)
            paint.shader = null
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = radius * .075f
            paint.color = Color.rgb(255,224,119)
            canvas.drawCircle(0f, 0f, radius * .88f, paint)
            paint.style = Paint.Style.FILL
            text.color = Color.rgb(105,66,12)
            text.textSize = radius * .65f
            canvas.drawText("R$", 0f, radius * .20f, text)
            text.textSize = radius * .23f
            canvas.drawText("1 REAL", 0f, radius * .52f, text)
            canvas.restore()

            if (revealed) {
                text.color = Color.WHITE
                text.textSize = 27f
                canvas.drawText("Você realmente tem", cx, h * .70f, text)
                text.color = Color.rgb(255,213,92)
                text.textSize = 34f
                canvas.drawText("um real?", cx, h * .77f, text)
                text.color = Color.LTGRAY
                text.textSize = 15f
                canvas.drawText("Toque na tela para ver de novo", cx, h * .87f, text)
            }
        }
    }
}
